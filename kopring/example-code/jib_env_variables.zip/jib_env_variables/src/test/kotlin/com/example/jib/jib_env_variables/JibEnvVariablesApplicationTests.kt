package com.example.jib.jib_env_variables

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class JibEnvVariablesApplicationTests {

	@Test
	fun contextLoads() {
	}

}
