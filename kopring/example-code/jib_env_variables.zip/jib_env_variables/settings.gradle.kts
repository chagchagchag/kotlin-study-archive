rootProject.name = "jib_env_variables"
