package com.demo.spring_cloud_contract.demo_contract_producer

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class DemoContractProducerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
